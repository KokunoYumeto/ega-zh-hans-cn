$ErrorActionPreference = 'Stop'
$taskHere = $PSScriptRoot
$taskEngine = (Get-Command lualatex -ErrorAction Stop).Source
$env:SOURCE_DATE_EPOCH = '1789948800'
$env:FORCE_SOURCE_DATE = '1'
Push-Location -LiteralPath $taskHere
try {
    foreach ($taskPass in 1..3) {
        & $taskEngine -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape 'ega3-2-zh-hans-cn.tex'
        if ($LASTEXITCODE -ne 0) {
            throw "LuaLaTeX 第 $taskPass 遍构建失败，退出码 $LASTEXITCODE。"
        }
    }
}
finally {
    Pop-Location
}
