# 重建 《代数几何原理 III-1》大陆简体中文 阅读版

本归档包含该 PDF 对应的完整单文件 LaTeX，以及等价的模块化前导文件、正文和驱动文件。需要安装含 ctex、TeX Gyre、Fandol、TikZ-cd 与 Xy-pic 的当前 TeX 发行版，并使用 LuaLaTeX。

在本目录运行三遍：

`	ext
lualatex -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape ega3-1-zh-hans-cn.tex
lualatex -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape ega3-1-zh-hans-cn.tex
lualatex -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape ega3-1-zh-hans-cn.tex
`

也可对模块化驱动文件 $(System.Collections.Specialized.OrderedDictionary.driver) 运行同样的三遍命令；两种入口包含同一译文。全部数学图均由 TeX 源代码生成，不需要外部图像。NUMDAM 权威 PDF 仅作证据使用，未收入本归档。本版不对 EGA 原文主张新的许可证。
